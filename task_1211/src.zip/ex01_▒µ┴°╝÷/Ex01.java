package ex01_길진수;

import java.util.Scanner;

public class Ex01 {
	public static void main(String[] args) {
//		1. 사용자로부터 3개의 정수를 입력받아 아래 요구사항대로 구현하라
//
//		- 클래스명 : InputNumber
//		- 배열은 사용하면 안된다
//		1) 최소값과 최대값 출력
//		2) 3개 숫자의 평균을 소수점 2자리까지 출력

		// 입력 메소드 import
		// 각각의 변수와 최대 최소값, 평균을 저장할 변수선언
		// 최대값과 최소값 찾기
		// 각각의 수를 더해 평군을 구하기
		// 결과 출력

		Scanner sc = new Scanner(System.in);

		int num1, num2, num3, max, min;
		double avg;

		System.out.println("3개의 정수를 띄어쓰기를 통해 입력하세요");
		num1 = sc.nextInt();
		num2 = sc.nextInt();
		num3 = sc.nextInt();

		if (num1 > num2) {
			max = num1;
			if (num3 > max)
				;
			max = num3;
		} else {
			max = num2;
			if (num3 > max) {
				max = num3;

			}
		}
		
		if(num1 < num2) {
			min = num1;
			if(num3 < min) {
				min = num3;
			}
		} else {
			min = num2;
			if(num3 < min) {
				min = num3;
			}
		}
		
		avg = (num1 + num2 + num3) / 3d;
		
		System.out.println("최소값 : " + min + ", 최대값 : " + max);
		System.out.printf("평균 : %.3f", avg);
		
		
		sc.nextLine();
		sc.close();
	}
}