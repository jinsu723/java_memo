package ex02_길진수;

public class Ex02 {
	public static void main(String[] args) {
//		2. 15부터 30까지 중 짝수의 합을 출력하라
//
//		- 클래스명 : Print
//		- 단, while문을 사용할 것
		
		// 클래스 만들기
		// 객체 생성
		// 15부터 30을 배열에 담기
		// 짝수들의 합을 저장할 변수 선언
		// while문 제어할 논리형 변수 선언
		// while문을 사용하여 30까지 수를 다 보면 while문 종료
		
		Print p = new Print();
		int[] ar = new int[16];
		int sum = 0;
		
		for(int i=0; i<ar.length; i++) {
			ar[i] = i+15;
		}
		
		boolean isTrue = true;
		while(isTrue) {
			for(int i=0; i<ar.length; i++) {
				if(ar[i]%2 == 0) {
					sum += ar[i];
				}
				if(i == 15) {
					isTrue = false;
				}
			}
		}
		
		p.print(sum);
	}
}
