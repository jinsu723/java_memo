package ex03_길진수;

import java.util.Scanner;

public class Ex03 {
	public static void main(String[] args) {
//		3. 아래 내용과 동일하게 출력하라(로직구성 필요없음)
//
//		(1) 피라미드 출력
//
//		- 클래스명 : Stars1
//		 
//
//		[입출력결과]
//		   *
//		  * *
//		 * * *
//
//		 
//
//		(2) 사용자로부터 행을 입력받아 입력받은 숫자만큼 행으로 직각삼각형 출력
//
//		- 클래스명 : Stars2
//		 
//
//		[입출력결과]
//
//		출력하고 싶은 행 입력 : 4
//		*
//		**
//		***
//
//		****
		
		// (1)
		for(int i=0; i<4; i++) {
			for(int j=3; j>i; j--) {
				System.out.print(" ");
			}
			for(int j=0; j<i+1; j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		
		
		
		// (2)
		Scanner sc = new Scanner(System.in);
		
		System.out.print("출력하고 싶은 행 입력 : ");
		int num = sc.nextInt();
		
		for(int i=0; i<num; i++) {
			for(int j=0; j<=i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
