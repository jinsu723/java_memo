package ex04_길진수;

public class Person {




//	(1) Person 클래스
//    - 필드 (private) : String name(학생 이름)
//    - 생성자 : 이름을 매개변수로 받아 초기화
//    - 메소드
//        getName() : name 필드의 값을 반환
	
	// 필드 선언
	// 생성자 만들기 매개변수 1개
	// 메소드 선언 리턴값 String
	
	private String name;
	
	Person(String name){
		this.name = name;
	}
	
	String getName() {
		return this.name;
	}
}
