package ex04_길진수;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
//		(3) Main 클래스
//	    메인 메소드 구현
//	    Student 객체를 생성하여 이름과 점수를 입력받는다(입력받을 점수는 0~100 범위 내, 입력클래스 사용)
//	    각 학생의 총점과 평균을 출력한다
		
		// 입력메소드 선언
		// 객체 생성
		// 입력받은 이름과 각 점수로 객체 생성
		// 입력은 0~100
		// 입력 범위 벗어나면 메시지 출력하고 프로그램 종료
		// 각 학생의 총점과 평균 출력
		
		Scanner sc = new Scanner(System.in);
		

		System.out.println("학생1의 이름과 java 점수, dbms점수, html점수를 띄어쓰기로 구분하여 입력하세요");
		Student st1 = new Student(sc.next(), sc.nextInt(), sc.nextInt(), sc.nextInt());			
		
		System.out.println("학생2의 이름과 java 점수, dbms점수, html점수를 띄어쓰기로 구분하여 입력하세요");
		Student st2 = new Student(sc.next(), sc.nextInt(), sc.nextInt(), sc.nextInt());

		
		System.out.println(st1.getName() + "의 총점은 : " + st1.getTotalScore() + "이고 평균은 : " + st1.getAverageScore() + "입니다");
		System.out.println(st2.getName() + "의 총점은 : " + st2.getTotalScore() + "이고 평균은 : " + st2.getAverageScore() + "입니다");
	}
}
